'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import { universitiesApi } from '@/lib/api'
import { Button } from '@/components/ui/button'
import UniversityCard from '@/components/university-card'

interface University {
  id: string
  name: string
  website: string
  country: string
  description?: string
  logo?: string
}

export default function UniversitiesPage() {
  const [universities, setUniversities] = useState<University[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [search, setSearch] = useState('')
  const [filteredUniversities, setFilteredUniversities] = useState<University[]>(
    []
  )

  useEffect(() => {
    fetchUniversities()
  }, [])

  useEffect(() => {
    const filtered = universities.filter(
      (uni) =>
        uni.name.toLowerCase().includes(search.toLowerCase()) ||
        uni.country.toLowerCase().includes(search.toLowerCase())
    )
    setFilteredUniversities(filtered)
  }, [search, universities])

  const fetchUniversities = async () => {
    try {
      setLoading(true)
      const data = await universitiesApi.getAll()
      setUniversities(data)
    } catch (err) {
      setError(
        err instanceof Error ? err.message : 'Failed to load universities'
      )
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between flex-col sm:flex-row gap-4">
        <div>
          <h1 className="text-3xl font-bold text-balance">
            Browse Universities
          </h1>
          <p className="text-muted-foreground mt-1">
            Explore and apply to universities worldwide
          </p>
        </div>
        <Link href="/dashboard">
          <Button variant="outline">Back to Applications</Button>
        </Link>
      </div>

      <div className="flex flex-col md:flex-row gap-4 items-center">
        <div className="flex-1 w-full">
          <input
            type="search"
            placeholder="Search universities by name or country..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full px-4 py-3 border border-border rounded-lg bg-card text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
          />
        </div>
      </div>

      {error && (
        <div className="p-4 bg-destructive/10 text-destructive rounded-lg">
          {error}
        </div>
      )}

      {loading ? (
        <div className="flex justify-center py-12">
          <div className="text-center">
            <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-muted-foreground">Loading universities...</p>
          </div>
        </div>
      ) : filteredUniversities.length === 0 ? (
        <div className="border-2 border-dashed border-border rounded-lg p-12 text-center">
          <h3 className="text-lg font-semibold mb-2">No universities found</h3>
          <p className="text-muted-foreground">
            Try adjusting your search criteria.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredUniversities.map((university) => (
            <UniversityCard key={university.id} university={university} />
          ))}
        </div>
      )}

      <div className="text-center pt-8 border-t border-border">
        <p className="text-muted-foreground mb-4">
          Showing {filteredUniversities.length} of {universities.length}{' '}
          universities
        </p>
      </div>
    </div>
  )
}
